# NodeJs Projects
## Project#02: Express Server

- Simple Node/Express Server
- Installing Express generator setting up routes and views
- Learning Jade
- Simple SPA