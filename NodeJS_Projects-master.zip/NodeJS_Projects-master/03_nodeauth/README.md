# NodeJs Projects
## Project#03: NodeAuth

- Login System Application using local Passport Express/MongoDB(mongoose)
- Validation with express-validator 
- Sessions and flash messages
- Multer for uploading users avatar
- Bootstrap theme
- Building block for further projects

### Show Case
![VIEWS](https://github.com/MAshrafM/NodeJS_Projects/blob/master/03_nodeauth/show.jpg)