# NodeJs Projects
## Project#10: ELearn

- NodeJs + Express + MongoDB + Mongoose
- Using Custom Theme KickStart.
- Login System for Students and Instructors.
- Register for Class and see Lessons in it.
- Adding Classes and Lessons.


Final Show Case
![VIEWS](https://github.com/MAshrafM/NodeJS_Projects/blob/master/10_ELearn/show.jpg)

### Future
- Adding Editor for Lessons.
- Adding Videos.
- Quiz System.
- Custom Style.
