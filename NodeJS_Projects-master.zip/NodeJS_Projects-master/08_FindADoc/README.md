# NodeJs Projects
## Project#08: Find A Doc

- NodeJs + Express
- Cassandra - Apachi database
- Simple CRUD for adding a doctor and a category.
- Search by name, state.

Final Show Case
![VIEWS](https://github.com/MAshrafM/NodeJS_Projects/blob/master/08_FindADoc/show.jpg)

### Future
- Show the place on a map.
- Add direction from current location.
- Improve Style.